import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../services/admin.service';
import { Router } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-admin-dashboard',
  templateUrl: './admin.component.html',
  imports: [CommonModule]
})
export class AdminComponent implements OnInit {
  users: any[] = [];

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers() {
    this.adminService.getUsers().subscribe(data => {
      this.users = data;
    });
  }

  deleteUser(username: string) {
    if (confirm(`Are you sure you want to delete ${username}?`)) {
      this.adminService.deleteUser(username).subscribe(() => {
        alert('User deleted');
        this.loadUsers(); // Refresh list
      });
    }
  }
}
