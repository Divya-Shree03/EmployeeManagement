import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ManagerService } from '../../services/manager.service';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../../services/auth.service';

interface MilestoneForm {
  milestoneDesc: string;
  targetDate: string;
  progressStatus: string;
}

interface GoalForm {
  employeeID: number;
  goalDesc: string;
  targetDate: string;
  progressStatus: string;
  milestones: MilestoneForm[];
}

interface Report {
  reportID: number;
  employeeID: number;
  date: string; // Backend sends LocalDate which will be serialized to string
  performancesummary: string;
  feedbacksummary: string;
}

interface ManagerProfile {
  employeeID: number;
  username: string;
  email: string;
  dept: string;
  mobileNo: string;
  roles: any[];
}

interface Goal {
  goalID: number;
  goalDesc: string;
  progressStatus: string;
  employee: { employeeID: number; username: string };
  milestones: Milestone[];
}

interface Milestone {
  milestoneID: number;
  milestoneDesc: string;
  targetDate: string;
  progressStatus: string;
}

interface PasswordForm {
  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
}

@Component({
  standalone: true,
  selector: 'app-manager-dashboard',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css'],
  imports: [CommonModule, FormsModule]
})
export class ManagerComponent implements OnInit {

  generateReportEmployeeId: number | null = null;
  generatedReport: Report | null = null;
  reportError: string = '';

  assignedGoals: Goal[] = [];
  goalsError: string = '';

  managerProfile: ManagerProfile | null = null;
  profileError: string = '';

  passwordForm: PasswordForm = {
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  };
  passwordUpdateMessage: string = '';
  passwordUpdateError: string = '';

  errorMessage: string = '';

  employeeForm = {
    username: '',
    email: '',
    password: '',
    dept: '',
    mobileNo: '',
    role: 'EMPLOYEE'
  };

  goalForm: GoalForm = {
    employeeID: 0,
    goalDesc: '',
    targetDate: '',
    progressStatus: 'Not Started',
    milestones: [{ milestoneDesc: '', targetDate: this.formatDate(new Date()), progressStatus: 'Not Started' }]
  };

  reviewForm = {
    employeeID: 0,
    managerID: 0,
    performanceScore: '',
    feedback: ''
  };

  constructor(private service: ManagerService, private auth: AuthService) { }

  ngOnInit() {
    this.showSection('addEmployeeSection'); // Show the Add New Employee section by default
  }

  showSection(sectionId: string) {
    const sections = ['addEmployeeSection', 'assignGoalSection', 'submitReviewSection', 'generateReportSection', 'updatePasswordSection', 'profileSection', 'viewAssignedGoalsSection'];
    sections.forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        element.classList.add('d-none');
      }
      const link = document.getElementById(id.replace('Section', 'Link'));
      if (link) {
        link.classList.remove('active');
      }
    });

    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
      selectedSection.classList.remove('d-none');
    }
    const selectedLink = document.getElementById(sectionId.replace('Section', 'Link'));
    if (selectedLink) {
      selectedLink.classList.add('active');
    }

    if (sectionId === 'profileSection' && !this.managerProfile) {
      this.loadManagerProfile();
    }
    else if (sectionId === 'viewAssignedGoalsSection' && !this.assignedGoals.length && !this.goalsError) {
      this.loadAssignedGoals();
    }
    else if (sectionId === 'updatePasswordSection') {
      this.passwordForm = { oldPassword: '', newPassword: '', confirmPassword: '' };
      this.passwordUpdateMessage = '';
      this.passwordUpdateError = '';
    }
  }

  loadManagerProfile() {
    this.service.getManagerProfile().subscribe({
      next: (profile) => {
        this.managerProfile = profile;
        this.profileError = '';
      },
      error: (error) => {
        this.managerProfile = null;
        this.profileError = 'Error loading profile.';
        console.error('Error loading manager profile:', error);
      }
    });
  }

  loadAssignedGoals() {
    this.service.getAssignedGoals().subscribe({
      next: (goals) => {
        this.assignedGoals = goals;
        this.goalsError = '';
      },
      error: (error) => {
        this.assignedGoals = [];
        this.goalsError = 'Error loading assigned goals.';
        console.error('Error loading assigned goals:', error);
      }
    });
  }

  addEmployee() {
    this.service.addEmployee(this.employeeForm).subscribe(() => {
      alert('Employee added successfully');
      this.employeeForm = {
        username: '', email: '', password: '', dept: '', mobileNo: '', role: 'EMPLOYEE'
      };
      this.showSection('addEmployeeSection'); // Stay on the same section or navigate elsewhere
    });
  }

  addMilestone() {
    this.goalForm.milestones.push({ milestoneDesc: '', targetDate: this.formatDate(new Date()), progressStatus: 'Not Started' });
  }

  removeMilestone(index: number) {
    this.goalForm.milestones.splice(index, 1);
  }

  assignGoal() {
    this.errorMessage = ''; // Clear any previous error message
    this.service.addGoal(this.goalForm).subscribe({
      next: (response) => {
        alert('Goal assigned successfully');
        this.goalForm = { employeeID: 0, goalDesc: '', targetDate: this.formatDate(new Date()), progressStatus: 'Not Started', milestones: [{ milestoneDesc: '', targetDate: this.formatDate(new Date()), progressStatus: 'Not Started' }] };
        this.showSection('assignGoalSection'); // Stay on the same section or navigate elsewhere
      },
      error: (error) => {
        console.error('Error assigning goal:', error);
        if (error.error && error.error.message) {
          this.errorMessage = error.error.message; // Extract the message from the error response
        } else if (error.error instanceof String || typeof error.error === 'string') {
          this.errorMessage = error.error;
        }
        else {
          this.errorMessage = 'Failed to assign goal. Please check the Employee ID.';
        }
        // Optionally, you can keep the assign goal section visible to allow the user to correct the input
        // this.showSection('assignGoalSection');
      }
    });
  }

  submitReview() {
    this.service.giveReview(this.reviewForm).subscribe(() => {
      alert('Review submitted successfully');
      this.reviewForm = { employeeID: 0, managerID: 0, performanceScore: '', feedback: '' };
      this.showSection('submitReviewSection'); // Stay on the same section or navigate elsewhere
    });
  }

  generateEmployeeReport() {
    if (this.generateReportEmployeeId) {
      this.service.generateReport(this.generateReportEmployeeId).subscribe({
        next: (report) => {
          this.generatedReport = report;
          this.reportError = '';
          console.log('Generated Report:', this.generatedReport);
          this.showSection('generateReportSection');
        },
        error: (error: HttpErrorResponse) => {
          this.generatedReport = null;
          if (error.status === 404) {
            // Check if the error response body contains a specific message
            if (error.error && typeof error.error === 'string' && error.error.includes('There is no employee')) {
              this.reportError = 'Employee with ID ' + this.generateReportEmployeeId + ' not found.';
            } else if (error.error && error.error.message && error.error.message.includes('There is no employee')) {
              this.reportError = 'Employee with ID ' + this.generateReportEmployeeId + ' not found.';
            } else if (error.error) {
              this.reportError = typeof error.error === 'string' ? error.error : error.error.message || 'Report not found.';
            } else {
              this.reportError = 'Report not found.';
            }
          } else {
            // Handle other error status codes
            this.reportError = error.error?.message || error.message || 'An unexpected error occurred.';
          }
          console.error('Report generation error:', error);
        }
      });
    } else {
      this.reportError = 'Please enter an Employee ID to generate the report.';
      this.generatedReport = null;
    }
  }

  updatePassword() {
    this.passwordUpdateMessage = '';
    this.passwordUpdateError = '';
    if (this.passwordForm.newPassword !== this.passwordForm.confirmPassword) {
      this.passwordUpdateError = 'New password and confirm password do not match.';
      return;
    }

    this.auth
      .updatePassword(this.passwordForm.oldPassword, this.passwordForm.newPassword)
      .subscribe({
        next: (response: any) => {
          this.passwordUpdateMessage = response.message;
          this.passwordForm = {
            oldPassword: '',
            newPassword: '',
            confirmPassword: '',
          };
          this.showSection('viewGoalsSection'); // Redirect or show success message
        },
        error: (error: HttpErrorResponse) => {
          if (error.error && error.error.error) {
            this.passwordUpdateError = error.error.error;
          } else if (error.message) {
            this.passwordUpdateError = error.message;
          } else {
            this.passwordUpdateError = 'Failed to update password.';
          }
        },
      });
  }

  logout() {
    this.auth.logout();
  }

  formatDate(date: Date): string {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  isMilestonesInvalid(): boolean {
    return this.goalForm.milestones.some(
      (m) => !m.milestoneDesc || !m.targetDate || !m.progressStatus
    );
  }
}