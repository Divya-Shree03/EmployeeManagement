import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule]
})
export class LoginComponent {
  username = '';
  password = '';
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  login() {
    this.auth.clearToken(); 
    this.auth.login({ username: this.username, password: this.password }).subscribe({
      next: (res: string) => {
        this.auth.saveToken(res); // Save JWT to localStorage
  
        const payload = JSON.parse(atob(res.split('.')[1])); // decode JWT
        const role = payload.roles[0];
  
        if (role === 'ADMIN') this.router.navigate(['/admin']);
        else if (role === 'MANAGER') this.router.navigate(['/manager']);
        else if (role === 'EMPLOYEE') this.router.navigate(['/employee']);
        else this.error = 'Unknown role';
      },
      error: () => this.error = 'Invalid credentials'
    });
  }
  
}
