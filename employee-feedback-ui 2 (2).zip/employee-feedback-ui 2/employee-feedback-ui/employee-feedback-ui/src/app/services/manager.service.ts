
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

interface EmployeeForm {
  username: string;
  email: string;
  password: string;
  dept: string;
  mobileNo: string;
  role: string;
}

interface MilestoneForm {
  milestoneDesc: string;
  targetDate: string;
  progressStatus: string;
}

interface GoalForm {
  employeeID: number;
  goalDesc: string;
  targetDate: string;
  progressStatus: string;
  milestones: MilestoneForm[];
}

interface ReviewForm {
  employeeID: number;
  managerID: number;
  performanceScore: string;
  feedback: string;
}

interface Report {
  reportID: number;
  employeeID: number;
  date: string;
  performancesummary: string;
  feedbacksummary: string;
}

interface ManagerProfile {
  employeeID: number;
  username: string;
  email: string;
  dept: string;
  mobileNo: string;
  roles: any[];
}

interface Goal {
  goalID: number;
  goalDesc: string;
  progressStatus: string;
  employee: { employeeID: number; username: string };
  milestones: Milestone[];
}


interface Milestone {
  milestoneID: number;
  milestoneDesc: string;
  targetDate: string;
  progressStatus: string;
}

@Injectable({
  providedIn: 'root'
})
export class ManagerService {
  private baseUrl = 'http://localhost:9092/manager';
  private http = inject(HttpClient);
  private auth = inject(AuthService);

  addEmployee(data: EmployeeForm): Observable<any> {
    return this.http.post(`${this.baseUrl}/addEmployee`, data, {
      headers: this.auth.getAuthHeaders()
    });
  }

  addGoal(data: GoalForm): Observable<any> {
    return this.http.post(`${this.baseUrl}/addGoal`, data, {
      headers: this.auth.getAuthHeaders()
    });
  }

  giveReview(data: ReviewForm): Observable<any> {
    return this.http.post(`${this.baseUrl}/giveReview`, data, {
      headers: this.auth.getAuthHeaders()
    });
  }

  generateReport(employeeId: number): Observable<Report> {
    return this.http.get<Report>(`${this.baseUrl}/getReportByID/${employeeId}`, {
      headers: this.auth.getAuthHeaders()
    });
  }

  getManagerProfile(): Observable<ManagerProfile> {
    return this.http.get<ManagerProfile>(`${this.baseUrl}/profile`, { headers: this.auth.getAuthHeaders() });
}

getAssignedGoals(): Observable<Goal[]> {
  return this.http.get<Goal[]>(`${this.baseUrl}/assigned-goals`, { headers: this.auth.getAuthHeaders() });
}

}