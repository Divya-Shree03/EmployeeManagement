import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject, tap } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:9092/auth';
  private tokenKey = 'authToken';
  private _loggedIn = new BehaviorSubject<boolean>(this.isLoggedIn());
  public loggedIn$ = this._loggedIn.asObservable();

  constructor(private router: Router) {}

  login(data: { username: string; password: string }): Observable<string> {
    return this.http.post(`${this.baseUrl}/login`, data, { responseType: 'text' }).pipe(
      tap((token: string) => {
        this.saveToken(token);
        this._loggedIn.next(true);
      })
    );
  }

  register(data: any): Observable<string> {
    return this.http.post(`${this.baseUrl}/register`, data, { responseType: 'text' });
  }

  saveToken(token: string) {
    localStorage.setItem('token', token);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getAuthHeaders(): HttpHeaders {
    return new HttpHeaders({
      Authorization: `Bearer ${this.getToken()}`,
    });
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  clearToken(): void {
    localStorage.removeItem('token');
    this._loggedIn.next(false);
  }

  updatePassword(oldPassword: string, newPassword: string): Observable<any> {
    const headers = this.getAuthHeaders();
    const params = { oldPassword: oldPassword, newPassword: newPassword };
    return this.http.post(`${this.baseUrl}/updatePassword`, null, { headers, params });
  }

  logout(): void {
    this.clearToken();
    this.router.navigate(['/login']);
  }
}